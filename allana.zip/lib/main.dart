import 'package:flutter/material.dart';
import 'package:allana/widget/login_page.dart';

void main() {
  runApp(
    const MaterialApp(
      home: LoginPage(),
    ),
  );
}
