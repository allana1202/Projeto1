package com.example.allana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
